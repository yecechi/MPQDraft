// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__14389205_96D1_4D21_B099_93AD280FD1EF__INCLUDED_)
#define AFX_STDAFX_H__14389205_96D1_4D21_B099_93AD280FD1EF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// Insert your headers here
#define _WIN32_WINDOWS 0x0500
#define WINVER 0x0500
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include <windows.h>
#include <assert.h>
#include <stdio.h>
#include <shlwapi.h>
#include <malloc.h>
#include <stdlib.h>
#include <crtdbg.h>

#include <QInjectDLL.h>
#include <QResource.h>
#include <QDebug.h>

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__14389205_96D1_4D21_B099_93AD280FD1EF__INCLUDED_)
